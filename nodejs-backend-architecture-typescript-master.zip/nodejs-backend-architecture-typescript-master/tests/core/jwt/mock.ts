import fs from 'fs';

export const readFileSpy = jest.spyOn(fs, 'readFile');
